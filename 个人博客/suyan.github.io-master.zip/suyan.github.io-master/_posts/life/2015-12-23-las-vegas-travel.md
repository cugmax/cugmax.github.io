---
layout: post
title: Las Vegas 自驾游
category: 生活
tags: essay
keywords: 加州,生活,California,Las Vegas
---

> Las Vegas 是美国必去的城市之一。有人说，要看100年前的美国要去 San Francisco，看50年前的美国要去 Los Angels，看现在的美国要去 Las Vegas。

<iframe src="https://www.google.com/maps/d/u/0/embed?mid=1kXmjUkO_U2ko7O0GGVQ4-br8xXg" width="640" height="480"></iframe>

## Outlets at Barstow

很大一个 Outlets，只是顺路上厕所...

## Bellagio Hotel

![Bellagio](http://7u2ho6.com1.z0.glb.clouddn.com/life-bellagio-resort.png)

![Bellagio](http://7u2ho6.com1.z0.glb.clouddn.com/life-bellagio-resort-2.png)

![Bellagio](http://7u2ho6.com1.z0.glb.clouddn.com/life-bellagio-resort-3.png)

## Hoover Dam

![Hoover Dam](http://7u2ho6.com1.z0.glb.clouddn.com/life-hoover-dam-1.png)

![Hoover Dam](http://7u2ho6.com1.z0.glb.clouddn.com/life-hoover-dam-2.png)

## Valley of Fire State Park

![Valley of Fire](http://7u2ho6.com1.z0.glb.clouddn.com/life-valley-of-fire-1.png)

![Valley of Fire](http://7u2ho6.com1.z0.glb.clouddn.com/life-valley-of-fire-2.png)


