module Jekyll
  VERSION = "3.3.0".freeze
end
