module Jekyll
  Generator = Class.new(Plugin)
end
